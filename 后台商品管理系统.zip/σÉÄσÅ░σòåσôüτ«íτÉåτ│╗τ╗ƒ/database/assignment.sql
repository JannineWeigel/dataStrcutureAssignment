-- MySQL dump 10.13  Distrib 8.0.31, for macos12 (arm64)
--
-- Host: 127.0.0.1    Database: zuoye1
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '商品id',
  `storage_id` int NOT NULL COMMENT '库存id',
  `name` varchar(255) NOT NULL COMMENT '商品名',
  `price` double NOT NULL COMMENT '商品价格',
  `description` varchar(255) NOT NULL COMMENT '商品描述',
  `status` int NOT NULL COMMENT '商品状态',
  `quantity` int NOT NULL COMMENT '售卖数量',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (6,4,'Tesla Model X',1999,'Tesla豪华7坐SUVTesla豪华7坐SUVTesla豪华7坐SUVTesla豪华7坐SUVTesla豪华7坐SUVTesla豪华7坐SUVTesla豪华7坐SUVTesla豪华7坐SUV',3,100),(7,5,'iPhone 14',19999,'2022全新灵动岛设计',3,100),(8,7,'iPhone 4s Pro',9999,'2022全新灵动岛设计',3,100),(9,7,'iPhone 4s',9999,'2022全新灵动岛设计',3,100),(10,7,'iPhone 4',9999,'2022全新灵动岛设计',3,100),(11,7,'iPhone 5s',99,'2022全新灵动岛设计',1,100),(12,7,'iPhone 5',1234,'全新外观设计，金属玻璃双拼材质！',1,100),(13,4,'Tesla Model S Plaid',1999999,'有史以来最快的电车',0,1),(14,7,'DaMi',1999,'LeiJun',0,19);
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase`
--

DROP TABLE IF EXISTS `purchase`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '订单id',
  `name` varchar(255) NOT NULL COMMENT '购买商品名称',
  `date` date NOT NULL COMMENT '购买时间',
  `quantity` int NOT NULL COMMENT '购买数量',
  `price` double NOT NULL COMMENT '购买单价',
  `description` varchar(255) NOT NULL COMMENT '商品说明',
  `status` int NOT NULL COMMENT '商品状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='进货信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase`
--

LOCK TABLES `purchase` WRITE;
/*!40000 ALTER TABLE `purchase` DISABLE KEYS */;
INSERT INTO `purchase` VALUES (9,'Tesla Model X','2023-10-07',100,799999,'The new area',2),(10,'Tesla Model X','2023-10-07',100,799999,'The new area',0),(11,'iPhone 13 Pro Max','2023-10-12',100,8999,'2021全新iPhone手机',0),(12,'iPhone 14 Pro','2023-10-12',100,9999,'2022全新灵动岛设计',2),(13,'iPhone 14 Pro','2023-10-12',100,9999,'2022全新灵动岛设计',2),(14,'iPhone 15 Pro','2023-10-12',100,9999,'2023高性能旗舰机',2),(15,'iPhone 15 Pro','2023-10-12',100,9999,'2023高性能旗舰机',2),(16,'iPhone 15 Pro','2023-10-12',100,9999,'2023高性能旗舰机',2),(17,'iPhone 4s','2023-10-12',500,99,'你的下一步iPhone何必是iPhone',2),(18,'iPhone 4s','2023-10-12',500,99,'你的下一步iPhone何必是iPhone',2),(19,'iPhone 6s','2023-10-12',200,989,'经典咏流传',0),(20,'iPhone 6s','2023-10-12',200,989,'经典咏流传',0),(21,'iPhone 6s','2023-10-12',200,989,'经典咏流传',0),(22,'CAMP Ace 7000 Pro','2023-10-12',19,12999,'全碳纤维公路车，105油碟大套',0),(23,'Pinarello Dogma F','2023-10-06',19,199999,'高端车，牌子货',0),(24,'Trek Madone SLR9','2023-09-25',12,128888,'极致的气动造形',0),(25,'mad','2023-09-13',23,232,'verwverv',0),(26,'mad','2023-09-13',23,232,'verwverv',0);
/*!40000 ALTER TABLE `purchase` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sell`
--

DROP TABLE IF EXISTS `sell`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sell` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '售卖',
  `product_id` int NOT NULL COMMENT '商品id',
  `name` varchar(255) NOT NULL COMMENT '售卖名称',
  `price` double NOT NULL COMMENT '售卖单价',
  `quantity` int NOT NULL COMMENT '售卖数量',
  `description` varchar(255) NOT NULL COMMENT '售卖商品描述',
  `status` int NOT NULL COMMENT '售卖状态',
  `date` varchar(255) NOT NULL COMMENT '售卖日期',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='售卖信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sell`
--

LOCK TABLES `sell` WRITE;
/*!40000 ALTER TABLE `sell` DISABLE KEYS */;
/*!40000 ALTER TABLE `sell` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `storage`
--

DROP TABLE IF EXISTS `storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `storage` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '库存id',
  `purchase_id` int DEFAULT NULL COMMENT '购买id',
  `name` varchar(255) NOT NULL COMMENT '商品名',
  `date` date NOT NULL COMMENT '入库时间',
  `quantity` int NOT NULL,
  `price` int DEFAULT NULL COMMENT '入库价格',
  `description` varchar(255) NOT NULL COMMENT '商品描述',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='库存信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `storage`
--

LOCK TABLES `storage` WRITE;
/*!40000 ALTER TABLE `storage` DISABLE KEYS */;
INSERT INTO `storage` VALUES (4,9,'Tesla Model X','2023-10-07',100,799999,'The new area'),(5,13,'iPhone 14 Pro','2023-10-12',200,9999,'2022全新灵动岛设计'),(6,16,'iPhone 15 Pro','2023-10-12',300,9999,'2023高性能旗舰机'),(7,18,'iPhone 4s','2023-10-12',1000,99,'你的下一步iPhone何必是iPhone');
/*!40000 ALTER TABLE `storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'admin1','admin1'),(2,'admin2','admin2'),(3,'admin3','admin3');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-14 22:41:37
