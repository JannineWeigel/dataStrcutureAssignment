const BASEURL = "api/"

export default {
    // 登录
    login: BASEURL + "login",

    // Post 添加商品
    product: BASEURL + "add-product",
    // Get 上架/下架商品
    modifyProductStatus: BASEURL + "modify-product-status",
    // 获取所有商品
    products: BASEURL + "products",
    // 获取指定条数的商品
    limitProduct: BASEURL + "limit-products",
    // 获取已上架商品
    puttedProducts: BASEURL + "putted-products",
    // 删除商品
    deleteProducts: BASEURL + "delete-product",
    // 修改商品信息
    modifyProduct: BASEURL + "modify-product",
    // 获取所有库存
    getAllStorage: BASEURL + "get-all-storage",
    // 搜索商品
    searchProduct: BASEURL + "search-product",

    /**
     * purchases
     * modify-purchase
     * add-purchase
     * */
    // 获取所有订单信息
    purchases: BASEURL + "purchases",
    // 修改订单状态
    modifyPurchase: BASEURL + "modify-purchase",
    // 新增订单信息
    addPurchase: BASEURL + "add-purchase",
    // 查询订单
    searchPurchase: BASEURL + "search-purchase",

    // 获取所有库存商品
}
