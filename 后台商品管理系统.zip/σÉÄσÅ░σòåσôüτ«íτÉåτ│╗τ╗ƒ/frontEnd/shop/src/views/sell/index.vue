<template>
  <div class="home">
    <div class="home-title">
      <span>销售管理</span>
    </div>

    <div class="top">
      <div class="search">
        <el-date-picker type="date" placeholder="开始日期" style="width: 150px;" v-model="start"></el-date-picker>
        <el-date-picker type="date" placeholder="结束日期" style="width: 150px;" v-model="end"></el-date-picker>
        <el-input placeholder="购买商品名称" style="width: 240px;" v-model="input"></el-input>
        <el-button type="primary" style="width: 80px;" @click="goSearch()">搜 索</el-button>
      </div>
      <div class="addition">
        <el-button type="primary" @click="addPurchase()">新增销售订单</el-button>
      </div>
    </div>

    <!--    表格-->
    <div class="data">
      <el-table
          :data="purchasesList"
          style="width: 80%; margin: 0 auto"
          :default-sort = "{prop: 'date', order: 'descending'}">
        <el-table-column
            prop="name"
            label="销售商品名称"
            width="200">
        </el-table-column>
        <el-table-column
            prop="date"
            label="销售商品时间"
            sortable
            width="150">
        </el-table-column>
        <el-table-column
            prop="price"
            label="销售商品价格"
            width="120">
        </el-table-column>
        <el-table-column
            prop="quantity"
            label="销售商品数量"
            width="120">
        </el-table-column>
        <el-table-column
            prop="description"
            label="销售商品描述"
            width="280"
            show-overflow-tooltip>
        </el-table-column>
        <el-table-column
            prop="status"
            label="销售商品状态"
            width="120">
        </el-table-column>
      </el-table>
    </div>

    <el-dialog title="新增销售订单" :visible.sync="dialogAdditionVisible">
      <el-form :model="additionPurchase">

        <el-form-item label="销售商品名称" required>
          <el-input v-model="additionPurchase.name" aria-required="true"></el-input>
        </el-form-item>
        <el-form-item label="销售商品价格" required>
          <el-input v-model="additionPurchase.price"></el-input>
        </el-form-item>
        <el-form-item label="销售商品描述" required>
          <el-input v-model="additionPurchase.description"></el-input>
        </el-form-item>
        <el-form-item label="销售商品数量" required>
          <el-input v-model="additionPurchase.quantity"></el-input>
        </el-form-item>
        <el-form-item label="销售商品日期" required>
          <el-date-picker
              placeholder="选择时间"
              type="date"
              v-model="additionPurchase.date"
              format="yyyy 年 MM 月 dd 日"
              value-format="yyyy-MM-dd">
          </el-date-picker>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogAdditionVisible = false">取 消</el-button>
        <el-button type="primary" @click="sendAddProduct()">提 交</el-button>
      </div>
    </el-dialog>

    <!--    分页-->
    <div class="bottom">
      <div id="bottom-con">
        <el-pagination
            @current-change="handleCurrentChange"
            hide-on-single-page
            :current-page="currentPage"
            :page-size="pageSize"
            background
            layout="pager"
            :total="purchases.length">
        </el-pagination>
      </div>
    </div>
  </div>
</template>

<script>
import api from "@/api";
import {mixin} from "@/config/mixin";
export default {
  data () {
    return {
      input: "",
      purchases: [],
      purchasesList: [],
      currentPage: 1,
      pageSize: 5,
      start: '',
      end: '',
      dialogAdditionVisible: false,
      additionPurchase: {
        name: "",
        date: "",
        quantity: "",
        price: "",
        description: "",
      }
    }
  },
  created() {
    if (!localStorage.getItem('adminLoginToken')) {
      this.$message({
        message: "请先登录！",
        type: "warning"
      })
    }

    // fetch
    let params = {
      method: 'GET',
      url: api.purchases,
      token: localStorage.getItem('adminLoginToken')
    }
    let self = this
    self.sendReq(params, res => {
      if (res.data.code === 1) {
        self.purchases = res.data.data
        for (let i = 0; i < self.purchases.length; i++) {
          self.purchases[i].status = this.parseStatus(self.purchases[i].status)
        }
        self.purchasesList = self.purchases.slice(0, 5)
      }
      else {
        self.$message({
          message: "获取失败！",
          type: "warning"
        })
        self.$message({
          message: "请尝试重新登录！",
          type: "warning"
        })
      }
    })
  },
  mixins: [mixin],
  methods: {
    parseStatus (status) {
      if (status === 0) return "未发货"
      if (status === 1) return "已发货"
      if (status === 2) return "已签收"
      return "未知状态"
    },
    counterParseStatus (status) {
      if (status === "未发货") return 0
      if (status === "已发货") return 1
      if (status === "已入库") return 2
    },
    handleCurrentChange (currentPage) {
      this.purchasesList = this.purchases.slice((currentPage-1)*5, currentPage*5);
    },
    goSearch () {
      if (!localStorage.getItem('adminLoginToken')) {
        this.$message({
          message: "请先登录！",
          type: "warning"
        })
      }

      if (this.end !== '' && this.start > this.end) {
        this.$message({
          message: "日期填写错误！",
          type: "warning"
        })
        return;
      }

      // fetch
      let params = {
        method: 'POST',
        url: api.searchPurchase,
        token: localStorage.getItem('adminLoginToken'),
        data: {
          name: this.input,
          start: this.start,
          end: this.end
        }
      }
      let self = this
      self.sendReq(params, res => {
        if (res.data.code === 1) {
          self.purchases = res.data.data
          for (let i = 0; i < self.purchases.length; i++) {
            self.purchases[i].status = this.parseStatus(self.purchases[i].status)
          }
          self.purchasesList = self.purchases.slice(0, 5)
        }
        else {
          self.$message({
            message: "获取失败！",
            type: "warning"
          })
          self.$message({
            message: "请尝试重新登录！",
            type: "warning"
          })
        }
      })
    },
    addPurchase () {
      this.dialogAdditionVisible = true
    },
    sendAddProduct () {
      if (!localStorage.getItem('adminLoginToken')) {
        this.$message({
          message: "请先登录！",
          type: "warning"
        })
      }

      if (this.additionPurchase.name === '' ||
          this.additionPurchase.price === '' ||
          this.additionPurchase.date === '' ||
          this.additionPurchase.description === '' ||
          this.additionPurchase.quantity === '') {
        this.$message({
          message: "把数据填全了😡！",
          type: "warning"
        })
        return;
      }

      // fetch
      let params = {
        method: 'POST',
        url: api.addPurchase,
        token: localStorage.getItem('adminLoginToken'),
        data: {
          name: this.additionPurchase.name,
          date: this.additionPurchase.date,
          price: this.additionPurchase.price,
          description: this.additionPurchase.description,
          quantity: this.additionPurchase.quantity,
        }
      }
      let self = this
      self.sendReq(params, res => {
        if (res.data.code === 1) {
          self.$message({
            message: "添加成功！",
            type: "success"
          })
          this.dialogAdditionVisible = false
        }
        else {
          self.$message({
            message: res.data.message,
            type: "warning"
          })
        }
      })
    }

  },
}
</script>

<style>
el-button {
  display: block;
}
.home {
  width: calc(100vw - 200px);
  height: calc(100vh - 60px);
  position: absolute;
  bottom: 0;
  right: 0;
  background-color: white;
}
.home-title {
  text-align: center;
  font-size: 32px;
  font-weight: bolder;
  color: var(--theme-color);
  position: relative;
  top: 16px;
  width: 100%;
  height: 64px;
}
.top {
  position: relative;
  width: 80%;
  margin: 24px auto 0;
  display: flex;
  justify-content: space-between;
}
.search {
  position: relative;
  width: 560px;
  display: flex;
  justify-content: space-between;
}
.data {
  width: 100%;
  height: 500px;
  display: block;
  position: relative;
  top: 28px;
}
.addition {
}
.bottom {
  width: 100%;
  position: relative;
}
#bottom-con {
  width: min-content;
  position: absolute;
  left: 50%;
  transform: translateX(-50%);
}
.ice {
  display: flex;
  justify-content: space-between;
}
el-form {
  display: flex;
  justify-content: space-between;
}

</style>
