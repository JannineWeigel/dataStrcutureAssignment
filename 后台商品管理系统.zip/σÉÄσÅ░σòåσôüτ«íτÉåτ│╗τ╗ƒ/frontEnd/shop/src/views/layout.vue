<template>
  <div id="root">
    <Header></Header>
    <div class="content">
      <Aside></Aside>
      <router-view>
      </router-view>
      <div id="cc">
        <h1>数据结构第一次项目大作业</h1>
        <h1>软件2341袁吉栋</h1>
      </div>
    </div>
  </div>
</template>

<script>
import Header from '../components/header/index.vue'
import Aside from '../components/aside/index.vue'
export default {
  components: {
    Header,
    Aside
  }
}
</script>

<style>
#root {
  position: relative;
}
.content {
  width: 100vw;
  height: calc(100vh - 60px);
  position: relative;
}
#cc {
  width: calc(100vw - 202px);
  height: calc(100vh - 62px);
  position: absolute;
  right: 1px;
  bottom: 1px;
  z-index: -1;
}
#cc h1 {
  text-align: center;
  margin-top: 64px;
}
</style>
