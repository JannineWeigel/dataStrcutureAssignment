<template>
  <div class="activity">
    <div class="activity-title">
      <span>党员信息添加</span>
    </div>
    <el-form ref="form" :model="form" label-width="80px" :inline="true">
      <el-form-item label="姓名" style="width: 100%" required>
        <el-input v-model="form.name" style="width: 500px"></el-input>
      </el-form-item>
      <el-form-item label="性别" required>
        <el-select v-model="form.gender" placeholder="请选择性别">
          <el-option label="男" value="Male"></el-option>
          <el-option label="女" value="Female"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="生日" required>
        <el-date-picker v-model="form.birthday"></el-date-picker>
      </el-form-item>
      <el-form-item label="入党日期" style="width: 100%" required>
        <el-date-picker v-model="form.join_date" style="width: 500px"></el-date-picker>
      </el-form-item>
      <el-form-item label="所属院系" style="width: 100%" required>
        <el-input v-model="form.major" style="width: 500px"></el-input>
      </el-form-item>
      <el-form-item label="电话" style="width: 100%" required>
        <el-input v-model="form.contact_number" style="width: 500px"></el-input>
      </el-form-item>
      <el-form-item label="邮箱" style="width: 100%">
        <el-input v-model="form.email" style="width: 500px"></el-input>
      </el-form-item>
      <el-form-item label="住址" style="width: 100%">
        <el-input v-model="form.address" style="width: 500px"></el-input>
      </el-form-item>
      <el-form-item style="position: relative; left: 80px">
        <el-button type="primary" @click="addParty()" style="width: 500px">提交</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
import api from "@/api";
import {mixin} from "@/config/mixin";

export default {
  mixins: [mixin],
  data () {
    return {
      form: {
        name: '',
        gender: '',
        birthday: '',
        join_date: '',
        education: '',
        major: '',
        address: '',
        contact_number: ''
      }
    }
  },
  methods: {
    addParty () {
      // fetch
      let params = {
        method: 'POST',
        url: api.addParty,
        token: localStorage.getItem('adminLoginToken'),
        data: {
          name: this.form.name,
          gender: this.form.gender,
          birthday: this.form.birthday,
          join_date: this.form.join_date,
          education: this.form.education,
          major: this.form.major,
          contact_number: this.form.contact_number,
          email: this.form.email,
          address: this.form.address,
        }
      }

      let self = this
      self.sendReq(params, res => {
        if (res.data.code === 1) {
          self.$message({
            message: res.data.message,
            type: "success"
          })
        }
        else {
          self.$message({
            message: "获取失败！",
            type: "warning"
          })
          self.$message({
            message: "请尝试重新登录！",
            type: "warning"
          })
        }
      })
    }
  }

}
</script>

<style>
.activity {
  width: calc(100vw - 200px);
  height: calc(100vh - 60px);
}
.activity-title {
  text-align: center;
  font-size: 36px;
  font-weight: bolder;
  color: var(--theme-color);
  position: relative;
  top: 32px;
}
.ice {
  display: flex;
  justify-content: space-between;
}
.pro {
  font-size: 16px;
  color: #000;
}
.el-form {
  position: relative;
  top: 64px;
  margin: 0 auto;
  width: 50%;
}
</style>


