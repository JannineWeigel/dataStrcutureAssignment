<template>
  <div class="activity">
    <div class="activity-title">
      <span>党员信息列表</span>
    </div>
    <div class="activity-table">
      <el-table
          :data="party"
          style="width: 80%; position: relative; top: 64px; margin: 0 auto;"
          max-height="500">
        <el-table-column
            prop="name"
            label="姓名">
        </el-table-column>
        <el-table-column
            prop="gender"
            label="性别">
        </el-table-column>
        <el-table-column
            prop="join_date"
            label="入党时间">
        </el-table-column>
        <el-table-column
            prop="major"
            label="所属院系">
        </el-table-column>
        <el-table-column
            label="操作"
            width="100">
          <template slot-scope="scope">
            <el-button type="text" size="medium" @click="handleClick(scope.row)">详情</el-button>
          </template>
        </el-table-column>
        <el-table-column
            label="评分"
            width="200">
          <template slot-scope="scope">
            <el-rate :colors="colors" v-model="scope.row.score"></el-rate>
          </template>
        </el-table-column>
      </el-table>
      <el-dialog :title="partyItem.name" :visible.sync="dialogTableVisible">
        <span>{{ partyItem.gender === 'Male' ? '男' : '女' }}</span>&nbsp;&nbsp;
        <span>{{ partyItem.birthday }}</span>

        <el-divider></el-divider>

        <div class="ice"><span>入党日期</span>
          <span class="pro">{{ partyItem.join_date }}</span></div>

        <el-divider></el-divider>

        <div class="ice"><span>学历</span>
          <span class="pro">{{ partyItem.education }}</span></div>

        <el-divider></el-divider>

        <div class="ice"><span>所属院系</span>
          <span class="pro">{{ partyItem.major }}</span></div>

        <el-divider></el-divider>

        <div class="ice" v-if="partyItem.contact_number"><span>联系电话</span>
          <span class="pro">{{ partyItem.contact_number }}</span></div>

        <el-divider v-if="partyItem.contact_number"></el-divider>

        <div class="ice"><span>邮箱</span>
          <span class="pro">{{ partyItem.email }}</span></div>

        <el-divider></el-divider>

        <div class="ice"><span>地址</span>
          <span class="pro">{{ partyItem.address }}</span></div>

      </el-dialog>

    </div>
  </div>
</template>

<script>
import api from "@/api";
import {mixin} from "@/config/mixin";
export default {
  data () {
    return {
      party: [],
      dialogTableVisible: false,
      partyItem: {},
      colors: ['#99A9BF', '#F7BA2A', '#FF9900'],
      values: null,
      map: []
    }
  },
  created() {
    if (!localStorage.getItem('adminLoginToken')) {
      this.$message({
        message: "请先登录！",
        type: "warning"
      })
    }

    // fetch
    let params = {
      method: 'GET',
      url: api.party,
      token: localStorage.getItem('adminLoginToken')
    }
    let self = this
    self.sendReq(params, res => {
      if (res.data.code === 1) {
        self.party = res.data.data
        for (let i = 0; i < self.party.length; i++) {
          self.map.push(self.party[i].score)
        }
      }
      else {
        self.$message({
          message: "获取失败！",
          type: "warning"
        })
      }
    })
  },
  mixins: [mixin],
  methods: {
    handleClick (data) {
      this.dialogTableVisible = true
      this.partyItem = data
    },
    changeScore (data) {
      let params = {
        method: 'GET',
        url: `${api.modifyScore}?name=${data.name}&score=${data.score}`,
        token: localStorage.getItem('adminLoginToken')
      }
      let self = this
      self.sendReq(params, res => {
        if (res.data.code === 1) {
          self.$message({
            message: res.data.message,
            type: "success"
          })
        }
        else {
          self.$message({
            message: "更新失败！",
            type: "warning"
          })
        }
      })
    }
  },
  watch: {
    party: {
      deep: true,
      handler(newVal, oldVal) {
        if (oldVal === undefined || oldVal.length === 0) {
          return
        }
        for (let i = 0; i < newVal.length; i++) {
          if (newVal[i].score !== this.map[i]) {
            this.changeScore(newVal[i])
            this.map[i] = newVal[i].score
          }
        }
      }
    }
  },
}
</script>

<style>
.activity {
  width: calc(100vw - 200px);
  height: calc(100vh - 60px);
}
.activity-title {
  text-align: center;
  font-size: 36px;
  font-weight: bolder;
  color: var(--theme-color);
  position: relative;
  top: 32px;
}
.ice {
  display: flex;
  justify-content: space-between;
}
.pro {
  font-size: 16px;
  color: #000;
}
</style>


