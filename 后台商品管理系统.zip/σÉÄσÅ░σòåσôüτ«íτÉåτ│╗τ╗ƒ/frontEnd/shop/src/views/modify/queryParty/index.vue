<template>
  <div class="activity">
    <div class="activity-title">
      <span>党员信息查询</span>
    </div>
    <el-form :inline="true" class="demo-form-inline">
      <el-form-item>
        <el-input v-model="key" placeholder="查询信息" style="width: 600px" @keydown.13.prevent="onSubmit()"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="onSubmit">查询</el-button>
      </el-form-item>
    </el-form>

    <div class="activity-table" v-if="party.length !== 0">
      <el-table
          :data="party"
          style="width: 80%; position: relative; top: 64px; margin: 0 auto;"
          max-height="500">
        <el-table-column
            prop="name"
            label="姓名">
        </el-table-column>
        <el-table-column
            prop="gender"
            label="性别">
        </el-table-column>
        <el-table-column
            prop="join_date"
            label="入党时间">
        </el-table-column>
        <el-table-column
            prop="major"
            label="所属院系">
        </el-table-column>
        <el-table-column
            label="操作">
          <template slot-scope="scope">
            <el-button type="text" size="medium" @click="handleClick(scope.row)">详情</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-dialog :title="partyItem.name" :visible.sync="dialogTableVisible">
        <span>{{ partyItem.gender === 'Male' ? '男' : '女' }}</span>&nbsp;&nbsp;
        <span>{{ partyItem.birthday }}</span>

        <el-divider></el-divider>

        <div class="ice"><span>入党日期</span>
          <span class="pro">{{ partyItem.join_date }}</span></div>

        <el-divider></el-divider>

        <div class="ice"><span>学历</span>
          <span class="pro">{{ partyItem.education }}</span></div>

        <el-divider></el-divider>

        <div class="ice"><span>所属院系</span>
          <span class="pro">{{ partyItem.major }}</span></div>

        <el-divider></el-divider>

        <div class="ice" v-if="partyItem.contact_number"><span>联系电话</span>
          <span class="pro">{{ partyItem.contact_number }}</span></div>

        <el-divider v-if="partyItem.contact_number"></el-divider>

        <div class="ice"><span>邮箱</span>
          <span class="pro">{{ partyItem.email }}</span></div>

        <el-divider></el-divider>

        <div class="ice"><span>地址</span>
          <span class="pro">{{ partyItem.address }}</span></div>

      </el-dialog>

    </div>
  </div>
</template>

<script>
import {mixin} from "@/config/mixin";
import api from "@/api";

export default {
  mixins: [mixin],
  data() {
    return {
      key: '',
      party: [],
      partyItem: {},
      dialogTableVisible: false
    }
  },
  methods: {
    handleClick (data) {
      this.dialogTableVisible = true
      this.partyItem = data
    },
    onSubmit() {
      let params = {
        method: 'GET',
        url: `${api.queryParty}?key=${this.key}`,
        token: localStorage.getItem('adminLoginToken'),
      }

      let self = this
      self.sendReq(params, res => {
        if (res.data.code === 1) {
          this.party = res.data.data
        }
        else {
          self.$message({
            message: "获取失败！",
            type: "warning"
          })
        }
      })
    }
  }
}

</script>

<style>
.activity {
  width: calc(100vw - 200px);
  height: calc(100vh - 60px);
}
.activity-title {
  text-align: center;
  font-size: 36px;
  font-weight: bolder;
  color: var(--theme-color);
  position: relative;
  top: 32px;
}
.ice {
  display: flex;
  justify-content: space-between;
}
.pro {
  font-size: 16px;
  color: #000;
}
.el-form {
  position: relative;
  top: 64px;
  margin: 0 auto;
  width: 60%;
}
</style>


