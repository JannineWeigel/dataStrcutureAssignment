<template>
  <div class="activity">
    <div class="activity-title">
      <span>党员活动列表</span>
    </div>
    <div class="activity-table">
      <el-table
          :data="activity"
          style="width: 80%; position: relative; top: 64px; margin: 0 auto;"
          max-height="500">
        <el-table-column
            prop="name"
            label="活动名称"
            width="200">
        </el-table-column>
        <el-table-column
            prop="organiser"
            label="活动老师"
            width="200"
            class="ellipsis">
        </el-table-column>
        <el-table-column
            prop="datetime"
            label="活动时间"
            width="250">
        </el-table-column>
        <el-table-column
            prop="address"
            label="活动地点">
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>

<script>
import api from "@/api";
import {mixin} from "@/config/mixin";
export default {
  data () {
    return {
      activity: []
    }
  },
  created() {
    if (!localStorage.getItem('adminLoginToken')) {
      this.$message({
        message: "请先登录！",
        type: "warning"
      })
    }

    // fetch
    let params = {
      method: 'GET',
      url: api.activity,
      token: localStorage.getItem('adminLoginToken')
    }
    let self = this
    self.sendReq(params, res => {
      if (res.data.code === 1) {
        self.activity = res.data.data
      }
      else {
        self.$message({
          message: "获取失败！",
          type: "warning"
        })
        self.$message({
          message: "请尝试重新登录！",
          type: "warning"
        })
      }
    })
  },
  mixins: [mixin],
}
</script>

<style>
.activity {
  width: calc(100vw - 200px);
  height: calc(100vh - 60px);
}
.activity-title {
  text-align: center;
  font-size: 36px;
  font-weight: bolder;
  color: var(--theme-color);
  position: relative;
  top: 32px;
}
</style>

