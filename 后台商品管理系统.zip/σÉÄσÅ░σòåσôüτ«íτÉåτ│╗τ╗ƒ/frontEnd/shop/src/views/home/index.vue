<template>
  <div class="home">
    <div class="home-title">
      <span>下午好，欢迎您登录</span>
    </div>
    <div class="home-table">
      <el-table
          :data="notify"
          style="width: 80%;position: relative; top: 128px; margin: 0 auto;"
          max-height="500">
        <el-table-column
            prop="title"
            label="标题"
            width="200">
        </el-table-column>
        <el-table-column
            prop="content"
            label="通知内容"
            class="ellipsis">
        </el-table-column>
        <el-table-column
            prop="date"
            width="200"
            label="发布时间">
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>

<script>
import api from "@/api";
import {mixin} from "@/config/mixin";
export default {
  data () {
    return {
      notify: []
    }
  },
  created() {
    if (!localStorage.getItem('adminLoginToken')) {
      this.$message({
        message: "请先登录！",
        type: "warning"
      })
    }

    // fetch
    let params = {
      method: 'GET',
      url: api.notify,
      token: localStorage.getItem('adminLoginToken')
    }
    let self = this
    self.sendReq(params, res => {
      if (res.data.code === 1) {
        self.notify = res.data.data.allNotify
      }
      else {
        self.$message({
          message: "获取失败！",
          type: "warning"
        })
        self.$message({
          message: "请尝试重新登录！",
          type: "warning"
        })
      }
    })
  },
  mixins: [mixin],
}
</script>

<style>
.home {
  width: calc(100vw - 200px);
  height: calc(100vh - 60px);
}
.home-title {
  text-align: center;
  font-size: 36px;
  font-weight: bolder;
  color: var(--theme-color);
  position: relative;
  top: 64px;
}
.el-table-column {
  white-space: nowrap; /* 不换行 */
  overflow: hidden; /* 溢出隐藏 */
  text-overflow: ellipsis; /* 文本溢出显示省略号 */
}

.el-table-column span {
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
}
</style>
