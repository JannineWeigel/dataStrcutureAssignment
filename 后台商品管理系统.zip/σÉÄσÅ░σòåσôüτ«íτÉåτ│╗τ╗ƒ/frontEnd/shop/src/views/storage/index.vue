<template>
  <div class="home">
    <div class="home-title">
      <span>库存管理</span>
    </div>

    <div class="top">
      <div class="search">
        <el-input
            placeholder="请输入内容"
            v-model="input"
            clearable
            @keydown.13.prevent="searchProduct()">
        </el-input>
        <el-button type="primary" @click="searchProduct()">搜 索</el-button>
      </div>
    </div>

    <!--    表格-->
    <div class="data">
      <el-table
          :data="storageList"
          style="width: 80%; margin: 0 auto"
          :default-sort = "{prop: 'price', order: 'descending'}">
        <el-table-column
            prop="name"
            label="商品名称"
            width="200">
        </el-table-column>
        <el-table-column
            prop="price"
            label="商品价格"
            sortable
            width="120">
        </el-table-column>
        <el-table-column
            prop="description"
            label="商品描述"
            width="280"
            style="height: 20px; overflow: hidden"
            show-overflow-tooltip>

        </el-table-column>
        <el-table-column
            prop="quantity"
            label="商品数量"
            width="120">
        </el-table-column>
        <el-table-column
            prop="date"
            label="库存日期"
            width="120">
        </el-table-column>
        <el-table-column
            label="操作"
            width="150">
          <template slot-scope="scope">
            <el-button type="text" size="medium" @click="handleClick(scope.row)">详情</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>

    <el-dialog :title="storageItem.name" :visible.sync="dialogVisible">
      <div class="ice"><span>商品价格</span>
        <span class="pro" style="color: red">¥{{ storageItem.price }}</span></div>

      <el-divider></el-divider>

      <div class="ice">
        <span class="pro">{{ storageItem.description }}</span>
      </div>

      <el-divider></el-divider>

      <div class="ice"><span>库存数量</span>
        <span class="pro">{{ storageItem.quantity }}</span>
      </div>

      <el-divider></el-divider>

      <div class="ice"><span>库存日期</span>
        <span class="pro">{{ storageItem.date }}</span>
      </div>

      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="dialogVisible = false">确 定</el-button>
      </span>
    </el-dialog>

    <!--    分页-->
    <div class="bottom">
      <div id="bottom-con">
        <el-pagination
            @current-change="handleCurrentChange"
            hide-on-single-page
            :current-page="currentPage"
            :page-size="pageSize"
            background
            layout="pager"
            :total="storage.length">
        </el-pagination>
      </div>
    </div>
  </div>
</template>

<script>
import api from "@/api";
import {mixin} from "@/config/mixin";
export default {
  data () {
    return {
      storage: [],
      storageList: [],
      storageItem: {},

      input: "",
      products: [],
      productsList: [],
      currentPage: 1,
      pageSize: 5,
      dialogVisible: false,
      productItem: {},
      dialogFormVisible: false,
      form: {},
      dialogPuttedVisible: false,
      dialogAdditionVisible: false,
      additionProduct: {
        storageId: '',
        storageName: '',
        name: '',
        price: '',
        description: '',
        quantity: '',
      },
      storageProducts: {},
      value: '',
      id: '',
      chooseItem: {},
    }
  },
  created() {
    if (!localStorage.getItem('adminLoginToken')) {
      this.$message({
        message: "请先登录！",
        type: "warning"
      })
    }

    // fetch
    let params = {
      method: 'GET',
      // url: `${api.limitProduct}?start=${(this.currentPage-1)*5+1}&num=${5}`,
      url: api.getAllStorage,
      token: localStorage.getItem('adminLoginToken')
    }
    let self = this
    self.sendReq(params, res => {
      if (res.data.code === 1) {
        self.storage = res.data.data
        self.storageList = self.storage.slice(0, 5)
      }
      else {
        self.$message({
          message: "获取失败！",
          type: "warning"
        })
        self.$message({
          message: "请尝试重新登录！",
          type: "warning"
        })
      }
    })
  },
  mixins: [mixin],
  methods: {
    parseStatus (status) {
      if (status === 0) return "未上架"
      if (status === 1) return "已上架"
      if (status === 2) return "已售罄"
      if (status === 3) return "已下架"
      return "未知状态"
    },
    counterParseStatus (status) {
      if (status === "未上架") return 0
      if (status === "已上架") return 1
      if (status === "已售罄") return 2
      if (status === "已下架") return 3
    },
    handleCurrentChange (currentPage) {
      this.productsList = this.products.slice((currentPage-1)*5, currentPage*5);
    },
    handleClick (data) {
      this.dialogVisible = true
      this.storageItem = data
    },
    handleTableClick (data) {
      this.form = data
      this.dialogFormVisible = true
    },
    modifyProduct () {
      if (!localStorage.getItem('adminLoginToken')) {
        this.$message({
          message: "请先登录！",
          type: "warning"
        })
      }

      // fetch
      let params = {
        method: 'POST',
        url: api.modifyProduct,
        token: localStorage.getItem('adminLoginToken'),
        data: {
          id: this.form.id,
          name: this.form.name,
          price: this.form.price,
          description: this.form.description,
          quantity: this.form.quantity,
        }
      }
      let self = this
      self.sendReq(params, res => {
        if (res.data.code === 1) {
          self.$message({
            message: "商品修改成功！",
            type: "success"
          })
          self.dialogFormVisible = false
        }
        else {
          self.$message({
            message: "获取失败！",
            type: "warning"
          })
        }
      })
    },
    modifyProductStatus (status) {
      if (!localStorage.getItem('adminLoginToken')) {
        this.$message({
          message: "请先登录！",
          type: "warning"
        })
      }

      // fetch
      let params = {
        method: 'GET',
        url: `${api.modifyProductStatus}?id=${this.productItem.id}&status=${status}`,
        token: localStorage.getItem('adminLoginToken'),
      }
      let self = this
      self.sendReq(params, res => {
        if (res.data.code === 1) {
          self.$message({
            message: "操作成功！",
            type: "success"
          })
          self.dialogPuttedVisible = false
          self.productItem.status = this.parseStatus(status === 1 ? 1 : 3)
        }
        else {
          self.$message({
            message: "操作失败！",
            type: "warning"
          })
        }
      })
    },
    handlePuttedClick (data) {
      this.productItem = data
      this.dialogPuttedVisible = true
    },
    addProduct () {
      this.getAllStorageProducts()
      this.dialogAdditionVisible = true
    },
    getAllStorageProducts () {
      if (!localStorage.getItem('adminLoginToken')) {
        this.$message({
          message: "请先登录！",
          type: "warning"
        })
      }

      // fetch
      let params = {
        method: 'GET',
        url: api.getAllStorage,
        token: localStorage.getItem('adminLoginToken'),
      }
      let self = this
      self.sendReq(params, res => {
        if (res.data.code === 1) {
          self.storageProducts = res.data.data
        }
        else {
          self.$message({
            message: "获取库存信息失败！",
            type: "warning"
          })
        }
      })
    },
    sendAddProduct () {
      this.checkAdditionProduct()
      if (!localStorage.getItem('adminLoginToken')) {
        this.$message({
          message: "请先登录！",
          type: "warning"
        })
      }

      // fetch
      let params = {
        method: 'POST',
        url: api.product,
        token: localStorage.getItem('adminLoginToken'),
        data: {
          storageId: this.value,
          storageName: this.findNameById(this.value),
          name: this.additionProduct.name,
          price: this.additionProduct.price,
          description: this.additionProduct.description,
          quantity: this.additionProduct.quantity,
        }
      }

      let self = this
      self.sendReq(params, res => {
        if (res.data.code === 1) {
          self.$message({
            message: "添加成功！",
            type: "success"
          })
          self.dialogAdditionVisible = false
          this.getAllProducts()
        }
        else {
          self.$message({
            message: "操作失败！",
            type: "warning"
          })
        }
      })
    },
    checkAdditionProduct () {
      const price = this.additionProduct.price;
      const quantity = this.additionProduct.quantity;

      // 使用isNaN()函数来检查是否为数字，使用parseFloat()来转换成数字类型
      if (isNaN(parseFloat(price)) || isNaN(parseFloat(quantity))) {
        this.$message({
          message: "价格填写错误！",
          type: "warning"
        })
      } else if (price < 0 || quantity < 0) {
        // 如果小于0，弹出错误提示
        this.$message({
          message: "数量填写错误！",
          type: "warning"
        })
      }
    },
    findNameById (id) {
      for (let i = 0; i < this.storageProducts.length; i++) {
        if (id === this.storageProducts[i].id) {
          return this.storageProducts[i].name
        }
      }
    },
    getAllProducts () {
      if (!localStorage.getItem('adminLoginToken')) {
        this.$message({
          message: "请先登录！",
          type: "warning"
        })
      }

      // fetch
      let params = {
        method: 'GET',
        // url: `${api.limitProduct}?start=${(this.currentPage-1)*5+1}&num=${5}`,
        url: api.products,
        token: localStorage.getItem('adminLoginToken')
      }
      let self = this
      self.sendReq(params, res => {
        if (res.data.code === 1) {
          self.products = res.data.data
          for (let i = 0; i < self.products.length; i++) {
            self.products[i].status = this.parseStatus(self.products[i].status)
          }
          self.productsList = self.products.slice(0, 5)
        }
        else {
          self.$message({
            message: "获取失败！",
            type: "warning"
          })
          self.$message({
            message: "请尝试重新登录！",
            type: "warning"
          })
        }
      })
    },
    searchProduct () {
      if (this.input === undefined || this.input === "") {
        this.$message({
          message: "请输入商品名！",
          type: "warning"
        })
        return;
      }
      if (!localStorage.getItem('adminLoginToken')) {
        this.$message({
          message: "请先登录！",
          type: "warning"
        })
        return;
      }

      // fetch
      let params = {
        method: 'GET',
        url: `${api.searchProduct}?name=${this.input}`,
        token: localStorage.getItem('adminLoginToken'),
      }
      let self = this
      self.sendReq(params, res => {
        if (res.data.code === 1) {
          console.log(res.data.data)
          self.products = res.data.data
          for (let i = 0; i < self.products.length; i++) {
            self.products[i].status = this.parseStatus(self.products[i].status)
          }
          self.productsList = self.products.slice(0, 5)
        }
        else {
          self.$message({
            message: "获取失败！",
            type: "warning"
          })
        }
      })
    },
  },
}
</script>

<style>
.home {
  width: calc(100vw - 200px);
  height: calc(100vh - 60px);
  position: absolute;
  bottom: 0;
  right: 0;
  background-color: white;
}
.home-title {
  text-align: center;
  font-size: 32px;
  font-weight: bolder;
  color: var(--theme-color);
  position: relative;
  top: 16px;
  width: 100%;
  height: 64px;
}
.top {
  position: relative;
  width: 80%;
  margin: 24px auto 0;
  display: flex;
  justify-content: space-between;
}
.search {
  position: relative;
  width: 500px;
}
.search > .el-button {
  position: absolute;
  right: 0;
}
.data {
  width: 100%;
  height: 500px;
  display: block;
  position: relative;
  top: 28px;
}
.addition {
}
.bottom {
  width: 100%;
  position: relative;
}
#bottom-con {
  width: min-content;
  position: absolute;
  left: 50%;
  transform: translateX(-50%);
}
.ice {
  display: flex;
  justify-content: space-between;
}

</style>
