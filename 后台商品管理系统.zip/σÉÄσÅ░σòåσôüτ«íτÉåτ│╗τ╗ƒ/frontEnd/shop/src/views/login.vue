<template>
  <div class="login">
    <div class="login-cover"></div>
    <div class="login-content">
      <div class="login-content-left">
        <img src="../assets/commodity.jpg" alt=""/>
      </div>
      <div class="login-content-right">
        <div class="login-content-right-title">
          <span>后台商品管理系统</span>
        </div>
        <div class="login-content-right-username">
          <input placeholder="用户名" v-model="username" type="text">
        </div>
        <div class="login-content-right-password">
          <input placeholder="密码" v-model="password" type="password">
        </div>
        <div class="login-content-right-login">
          <button @click.prevent="state === '登录' ? login() : register()">{{ state }}</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import api from "@/api";
import {mixin} from "@/config/mixin";
export default {
  mixins: [mixin],
  data () {
    return {
      username: '',
      password: '',
      state: '登录'
    }
  },
  methods : {
    verify () {
      // verify
      if (this.username === '' || this.password === '') {
        this.$message({
          message: "用户名或密码不可以为空！",
          type: 'warning'
        })
        return false
      }
      if (!/^[0-9a-zA-Z]{6,18}$/.test(this.username) || !/^[0-9a-zA-Z]{6,18}$/.test(this.password)) {
        this.$message({
          message: "用户名或密码格式错误！",
          type: 'warning'
        })
        return false
      }
      return true
    },
    login () {

      if (!this.verify()) return false

      // login
      let params = {
        method: 'POST',
        url: api.login,
        data: {
          username: this.username,
          password: this.password
        }
      }
      let self = this
      self.sendReq(params, res => {
        if (res.data.code === 1) {
          localStorage.setItem('adminLoginToken', res.data.data)
          self.$message({
            message: `你好，${this.username}`,
            type: "success"
          })
          localStorage.setItem('admin-username', this.username)
          this.$router.push({
            path: "index",
            name: "index"
          })
        }
        else {
          self.$message({
            message: res.data.message,
            type: "warning"
          })
        }
      })

    },
    register () {

      if (!this.verify()) return false

      let params = {
        method: 'POST',
        url: api.register,
        data: {
          username: this.username,
          password: this.password
        }
      }
      let self = this
      self.sendReq(params, res => {
        if (res.data.code !== 1) {
          self.$message({
            message: res.data.message,
            type: "warning"
          })
        }
        else {
          self.$message({
            message: res.data.message,
            type: "success"
          })
        }
      })

    }
  }
}
</script>

<style>
.login {
  width: 100vw;
  height: 100vh;
  position: relative;
  overflow: hidden;
}
.login-cover {
  width: 110vw;
  height: 110vh;
  position: relative;
  left: -30px;
  overflow: hidden;
  background-color: #efefef;
  z-index: -1;
}

.login-cover::before {
  content: ''; /* 使用伪元素创建一个占位元素 */
  display: block; /* 设置为块级元素 */
  padding-top: 100%; /* 设置高度为宽度的百分比，以保持宽高比为1:1 */
}


.login-content {
  width: 768px;
  height: 384px;
  background-color: white;
  border-radius: 32px;
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
}


.login-content-left {
  width: 384px;
  height: 384px;
  position: absolute;
  left: 0;
}

.login-content-left img {
  width: 384px;
  height: 384px;
  border-radius: 32px;
}


.login-content-right {
  width: 384px;
  height: 384px;
  position: absolute;
  right: 0;
}
.login-content-right-title {
  color: var(--theme-color);
  font-size: 24px;
  position: absolute;
  left: 79px;
  top: 32px;
}
.login-content-right-username {

}
.login-content-right-username input {
  width: 240px;
  height: 40px;
  border-radius: 8px;
  outline: none;
  border: 1px solid var(--theme-color);
  padding-left: 16px;
  position: absolute;
  left: 50%;
  transform: translateX(-50%);
  top: 99px;
}

.login-content-right-password input {
  width: 240px;
  height: 40px;
  border-radius: 8px;
  outline: none;
  border: 1px solid var(--theme-color);
  padding-left: 16px;
  position: absolute;
  left: 50%;
  transform: translateX(-50%);
  top: 172px;
}
.login-content-right-login button {
  width: 258px;
  height: 41px;
  border-radius: 8px;
  background-color: var(--theme-color);
  padding-left: 16px;
  position: absolute;
  left: 50%;
  transform: translateX(-50%);
  top: 245px;
  border: 0;
  color: white;
}
.login-content-right-register a{
  color: var(--theme-color);
  font-size: 16px;
  position: absolute;
  top: 304px;
  left: 258px;
  text-decoration: none;
}
</style>
