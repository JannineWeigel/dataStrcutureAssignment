<template>
  <div class="cultivate">
    <div class="cultivate-title">
      <span>党员培训列表</span>
    </div>
    <div class="cultivate-table">
      <el-table
          :data="cultivate"
          style="width: 80%;position: relative; top: 64px; margin: 0 auto;"
          max-height="500">
        <el-table-column
            prop="name"
            label="培训名称"
            width="200">
        </el-table-column>
        <el-table-column
            prop="organiser"
            label="培训老师"
            width="200"
            class="ellipsis">
        </el-table-column>
        <el-table-column
            prop="date"
            label="培训时间"
            width="250">
        </el-table-column>
        <el-table-column
            prop="address"
            label="培训地点">
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>

<script>
import api from "@/api";
import {mixin} from "@/config/mixin";
export default {
  data () {
    return {
      cultivate: []
    }
  },
  created() {
    if (!localStorage.getItem('adminLoginToken')) {
      this.$message({
        message: "请先登录！",
        type: "warning"
      })
    }

    // fetch
    let params = {
      method: 'GET',
      url: api.cultivate,
      token: localStorage.getItem('adminLoginToken')
    }
    let self = this
    self.sendReq(params, res => {
      if (res.data.code === 1) {
        self.cultivate = res.data.data.allCultivate
      }
      else {
        self.$message({
          message: "获取失败！",
          type: "warning"
        })
        self.$message({
          message: "请尝试重新登录！",
          type: "warning"
        })
      }
    })
  },
  mixins: [mixin],
}
</script>

<style>
.cultivate {
  width: calc(100vw - 200px);
  height: calc(100vh - 60px);
}
.cultivate-title {
  text-align: center;
  font-size: 36px;
  font-weight: bolder;
  color: var(--theme-color);
  position: relative;
  top: 32px;
}
</style>
