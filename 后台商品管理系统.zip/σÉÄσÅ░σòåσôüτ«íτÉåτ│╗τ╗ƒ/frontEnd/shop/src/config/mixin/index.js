/*
* 创建axios实例，设置请求头。
* 导出封装的请求方法，传入封装好的数据（URL、Method等）
* 调用回调函数
* **/

import axios from "axios";

const request = axios.create({
    // withCredentials: true,
    timeout: 20000 // 请求超时 20s
})

request.interceptors.request.use(config => {
    // config.headers['token'] = localStorage.getItem('token')
    return config
})

export const mixin = {
    methods: {
        sendReq (params, callback) {
            request({
                method: params.method || 'POST',
                url: params.url,
                data: params.data || '',
                headers: {
                    'token': params.token,
                },
            }).then (res => {
                callback(res)
            })
        }
    }
}
