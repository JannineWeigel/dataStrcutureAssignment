<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  created() {
    if (!localStorage.getItem('adminLoginToken')) {
      this.$router.push({
        path: "login",
        name: "login"
      })
    }
    else {
      this.$router.push({
        path: "index",
        name: "index"
      })
    }
  }
}
</script>

<style>
* {
  margin: 0;
}
#app {
  position: relative;
}
</style>
