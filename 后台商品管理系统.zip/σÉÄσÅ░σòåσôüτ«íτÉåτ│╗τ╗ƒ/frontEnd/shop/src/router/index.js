import Vue from "vue";
import VueRouter from 'vue-router'
Vue.use(VueRouter)

import login from '../views/login.vue'
import layout from '../views/layout.vue'
import home from '../views/home/index.vue'

import product from '../views/product/index.vue'
import purchase from "../views/purchase/index.vue"
import sell from "../views/sell/index.vue"
import storage from "../views/storage/index.vue"

const router = new VueRouter({
    routes: [
        {
            path: "/index",
            name: "index",
            component: layout,
            children: [
                {
                    path: "home",
                    name: "home",
                    component: home,
                },
                {
                    path: "product",
                    name: "product",
                    component: product,
                },
                {
                    path: "purchase",
                    name: "purchase",
                    component: purchase,
                },
                {
                    path: "sell",
                    name: "sell",
                    component: sell,
                },
                {
                    path: "storage",
                    name: "storage",
                    component: storage,
                },

            ]
        },
        {
            path: "/login",
            name: "login",
            component: login,
        },
    ]
})

export default router
