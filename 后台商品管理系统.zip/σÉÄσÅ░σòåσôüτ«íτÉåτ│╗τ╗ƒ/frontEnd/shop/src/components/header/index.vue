<template>
  <div class="header">
    <div class="header-content">
      <div class="header-content-left">
        <span>后台商品管理系统</span>
      </div>
      <div class="header-content-right">
        <div class="header-content-welcome">
          <span>欢迎您：{{ username }}</span>
        </div>
        <div class="header-content-logout">
          <a href="#" @click.prevent="logout()">退出登录</a>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data () {
    return {
      username: localStorage.getItem('admin-username') || ''
    }
  },
  methods: {
    logout () {
      localStorage.removeItem('admin-username')
      localStorage.removeItem('adminLoginToken')
      this.username = ''
      this.$router.push({
        path: "login",
        name: "login"
      })
    }
  }
}
</script>

<style>
.header {
  width: 100vw;
  height: 60px;
  background-color: var(--theme-color);
  position: relative;
}
.header-content {
  width: calc(100vw - 64px);
  height: 60px;
  margin: 0 auto;
  display: flex;
  justify-content: space-between;
}

.header-content-left {
  font-size: 24px;
  font-weight: bolder;
  color: white;
  line-height: 60px;
}


.header-content-right {
  display: flex;
  width: 350px;
  justify-content: space-between;
}
.header-content-welcome {
  font-size: 20px;
  font-weight: bolder;
  color: white;
  line-height: 60px;
}
.header-content-logout,
.header-content-change-password {
  width: 64px;
  height: 22px;
  background-color: white;
  font-size: 12px;
  color: var(--theme-color);
  text-align: center;
  line-height: 22px;
  border-radius: 4px;
  position: relative;
  top: 20px;
}
.header-content-logout a,
.header-content-change-password a {
  text-decoration: none;
}
</style>
