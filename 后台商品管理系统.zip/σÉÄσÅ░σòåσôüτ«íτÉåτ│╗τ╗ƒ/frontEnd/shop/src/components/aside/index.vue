<template>
  <div class="aside">
    <el-menu style="width: 200px; height: calc(100vh - 60px)">

      <el-menu-item index="1" @click="toProduct()">
        <i class="el-icon-s-goods"></i>
        <span slot="title">商品管理</span>
      </el-menu-item>

      <el-menu-item index="2" @click="toPurchase()">
        <i class="el-icon-sold-out"></i>
        <span slot="title">进货管理</span>
      </el-menu-item>

      <el-menu-item index="3" @click="toSell()">
        <i class="el-icon-sell"></i>
        <span slot="title">销售管理</span>
      </el-menu-item>

      <el-menu-item index="4" @click="toStorage()">
        <i class="el-icon-house"></i>
        <span slot="title">库存管理</span>
      </el-menu-item>

    </el-menu>
  </div>
</template>

<script>
export default {
  methods: {
    toHome () {
      this.$router.push({
        path: "/index/home",
        name: "home"
      })
    },
    toProduct () {
      this.$router.push({
        path: "/index/product",
        name: "product"
      })
    },
    toPurchase () {
      this.$router.push({
        path: "/index/purchase",
        name: "purchase"
      })
    },
    toSell () {
      this.$router.push({
        path: "/index/sell",
        name: "sell"
      })
    },
    toStorage () {
      this.$router.push({
        path: "/index/storage",
        name: "storage"
      })
    },
  }
}
</script>

<style>
.aside {
  width: 200px;
  height: calc(100vh - 60px);
  position: relative;
  z-index: 2;
}
</style>
