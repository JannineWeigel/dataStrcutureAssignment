import Vue from 'vue'
import App from './App.vue'
import router from './router'

Vue.config.productionTip = false

// 配置elementUI
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
Vue.use(ElementUI);
Vue.prototype.$message = ElementUI.Message

new Vue({
  render: h => h(App),
  router
}).$mount('#app')
