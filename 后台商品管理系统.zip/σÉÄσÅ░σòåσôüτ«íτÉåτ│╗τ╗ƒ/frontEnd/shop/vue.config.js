module.exports = {
    devServer: {
        proxy: {
            '/api': {
                target: 'http://localhost:8088/api',
                ws: true,
                changeOrigin: true,
                pathRewrite: {
                    '^/api': ''
                }
            },
        },
        host: 'localhost',
        port: 5005,
    },
    lintOnSave: false,
    publicPath: '/'

}
