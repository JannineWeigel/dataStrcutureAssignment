package com.yuanjidong.shop.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author 袁吉栋
 * @date 2023/9/16
 * @description 类ProductModel实体封装了商品的属性
 * */

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProductModel {

    private Integer id;
    private Integer storage_id;
    private String name;
    private double price;
    private String description;
    private Integer status;
    private Integer quantity;

}
