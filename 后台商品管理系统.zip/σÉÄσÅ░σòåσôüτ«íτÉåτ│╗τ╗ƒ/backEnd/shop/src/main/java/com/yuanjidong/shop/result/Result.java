package com.yuanjidong.shop.result;

/**
 * @author 袁吉栋
 * @date 2023/9/16
 * @description 类Result实体封装了各种响应结果
 * */

public class Result {

    private int code;  // 1:成功，0:失败

    private String message;  // 失败或成功的提示信息

    private Object data;  // 数据

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public Result(int code, String message, Object data) {
        this.code = code;
        this.message = message;
        this.data = data;
    }

    // 默认成功方法
    public static Result success () {
        return new Result(1, "success", null);
    }

    // 指定返回数据的成功方法
    public static Result success (Object data) {
        return new Result(1, "success", data);
    }

    // 默认失败方法
    public static Result error () {
        return new Result(0, "error", null);
    }

    // 指定返回提示的失败方法
    public static Result error (String message) {
        return new Result(0, message, null);
    }

    // 默认返回全参方法
    public static Result result (int code, String message, Object data) {
        return new Result(code, message, data);
    }

}
