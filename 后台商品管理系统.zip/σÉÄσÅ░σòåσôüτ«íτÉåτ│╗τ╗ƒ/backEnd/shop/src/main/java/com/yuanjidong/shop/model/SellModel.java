package com.yuanjidong.shop.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author 袁吉栋
 * @date 2023/9/16
 * @description 类ProductModel实体封装了售卖商品的属性
 * */

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SellModel {

    private Integer id;
    private Integer product_id;
    private String name;
    private String date;
    private Integer quantity;
    private Double price;
    private String description;
    private Integer status;

}
