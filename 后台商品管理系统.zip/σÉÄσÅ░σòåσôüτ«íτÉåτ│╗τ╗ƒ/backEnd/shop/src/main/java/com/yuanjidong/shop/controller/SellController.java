package com.yuanjidong.shop.controller;

import com.yuanjidong.shop.result.Result;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SellController {

    @GetMapping("api/sells")
    public Result getAllSells() {
        return Result.success();
    }

}
