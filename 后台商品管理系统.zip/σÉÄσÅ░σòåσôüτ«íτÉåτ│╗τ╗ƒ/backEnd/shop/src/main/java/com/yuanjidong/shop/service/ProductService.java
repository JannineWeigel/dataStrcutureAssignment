package com.yuanjidong.shop.service;

import com.yuanjidong.shop.mapper.ProductMapper;
import com.yuanjidong.shop.model.ProductModel;
import com.yuanjidong.shop.model.StorageModel;
import com.yuanjidong.shop.model.UserModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

/**
 * @author 袁吉栋
 * @date 2023/9/16
 * @description 类ProductService抽离了一些关于产品的繁琐业务逻辑
 * */

@Service
public class ProductService {

    private final ProductMapper productMapper;

    @Autowired
    public ProductService (ProductMapper productMapper) {
        this.productMapper = productMapper;
    }

    // 验证仓库的商品是否有效
    public int checkStorageProduct (int storageId, String storageName) {
        // 验证上架的商品id是否包含在仓库内
        if (productMapper.checkExist(storageId, storageName) > 0) {
            return 0;
        }
        return -1;
    }

    // 验证提交的新增商品信息是否有效
    public int checkAdditionProduct (ProductModel productModel, int storageId) {
        // 商品名称不可为空
        if (productModel.getName() == null || productModel.getName().isEmpty()) {
            return 2;
        }

        // 商品价格不可小于0
        if (productModel.getPrice() < 0) {
            return 3;
        }

        // 商品描述不可为空
        if (productModel.getDescription() == null || productModel.getDescription().isEmpty()) {
            return 4;
        }

        // 商品数量不可大于库存数量
        if (productMapper.getStorageQuantity(storageId) < productModel.getQuantity()) {
            return 5;
        }

        return 1;
    }

    // 添加商品
    public void addProduct (ProductModel productModel) {
        productMapper.addProduct(productModel);
    }

    /**
     * 0:未上架
     * 1:已上架
     * 2:已售罄
     * 3:已下架
     * */
    // 验证上架是否合法：上架前商品状态只能为未上架或已下架(从已下架变为上架时商品数量不可为0)
    public int checkPutProduct (int id, int status) {
        // 从已下架变为已上架，要检查库存的数量是否大于0
        if (productMapper.checkPutProduct(id) == 0 || (
                productMapper.checkPutProduct(id) == 3 &&
                        productMapper.getStorageQuantityByProductId(id) > 0)) {
            productMapper.setProductStatus(id, status);
            return 1;
        }
        return 0;
    }

    // 验证下架是否合法：下架前商品状态只能为已上架或已售磬
    public int checkDeleteProduct (int id, int status) {
        if (productMapper.checkPutProduct(id) == 1 || productMapper.checkPutProduct(id) == 2) {
            productMapper.setProductStatus(id, status);
            return 1;
        }
        return 0;
    }

    // 获取所有商品
    public ArrayList<ProductModel> getAllProduct () {
        return productMapper.getAllProduct();
    }

    // 获取所有上架商品
    public ArrayList<ProductModel> getAllPuttedProduct () {
        return productMapper.getAllPuttedProduct();
    }

    // 删除商品
    public void deleteProduct (int id) {
        productMapper.deleteProduct(id);
    }

    // 获取指定条数商品
    public ArrayList<ProductModel> limitProducts (int start, int num) {
        return productMapper.limitProducts(start, num);
    }

    // 修改商品信息
    public void updateProduct (ProductModel productModel) {
        productMapper.updateProduct(productModel);
    }

    // 获取所有库存
    public ArrayList<StorageModel> getAllStorage () {
        return productMapper.getAllStorage();
    }

    // 搜索商品
    public ArrayList<ProductModel> searchProductByName (String name) {
        return productMapper.searchProductByName("%" + name + "%");
    }

}
