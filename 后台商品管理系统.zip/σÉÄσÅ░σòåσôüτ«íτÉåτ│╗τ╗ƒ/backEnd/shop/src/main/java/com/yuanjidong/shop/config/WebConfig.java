package com.yuanjidong.shop.config;

import com.yuanjidong.shop.intercepter.Authority;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * @author 袁吉栋
 * @date 2023/9/16
 * @description 类WebConfig实现WebMvcConfigurer接口添加拦截器以判断是否登录
 * */

@Configuration
@EnableWebMvc
public class WebConfig implements WebMvcConfigurer {

    private final Authority authority;

    @Autowired
    public WebConfig (Authority authority) {
        this.authority = authority;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(authority)
                .addPathPatterns("/**")
                .excludePathPatterns("/login");
    }
}
