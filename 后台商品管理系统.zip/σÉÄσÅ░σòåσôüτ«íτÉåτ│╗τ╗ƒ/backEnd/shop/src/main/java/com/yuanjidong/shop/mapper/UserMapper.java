package com.yuanjidong.shop.mapper;

import com.yuanjidong.shop.model.UserModel;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

/**
 * @author 袁吉栋
 * @date 2023/9/16
 * @description 接口UserMapper声明接口并操作有关用户user表
 * */

@Mapper
public interface UserMapper {

    // 查找是否有匹配的用户名和密码
    @Select("SELECT * FROM user WHERE username = #{username} AND password = #{password}")
    UserModel verifyUser (String username, String password);

}
