package com.yuanjidong.shop.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AdditionProductModel {

    private Integer storageId;
    private String storageName;
    private String name;
    private double price;
    private String description;
    private Integer quantity;

}
