package com.yuanjidong.shop.controller;

import com.yuanjidong.shop.model.AdditionProductModel;
import com.yuanjidong.shop.model.ProductModel;
import com.yuanjidong.shop.result.Result;
import com.yuanjidong.shop.service.ProductService;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @author 袁吉栋
 * @date 2023/9/21
 * @description 类ProductController负责接收有关商品操作的接口功能
 * */

@RestController
public class ProductController {

    private final ProductService productService;

    @Autowired
    public ProductController (ProductService productService) {
        this.productService = productService;
    }

    /**
     * int storageId  库存id
     * String storageName  库存名称
     * String name  商品名称
     * double price  商品价格
     * String description  商品描述
     * int quantity  新增商品数量
     *
     * @description 新增商品（非上架商品）
     *      1.验证上架的商品id是否包含在仓库内
     *      2.验证该商品的状态只能为：未上架
     *      3.商品名称不可为空
     *      4.商品价格不可小于0
     *      5.商品描述不可为空
     *      6.商品数量不可大于库存数量
     * */
    @PostMapping("api/add-product")
    public Result addProduct (@RequestBody AdditionProductModel additionProductModel) {
        int storageId = additionProductModel.getStorageId();
        String storageName = additionProductModel.getStorageName();
        ProductModel productModel = new ProductModel();
        productModel.setName(additionProductModel.getName());
        productModel.setPrice(additionProductModel.getPrice());
        productModel.setDescription(additionProductModel.getDescription());
        productModel.setQuantity(additionProductModel.getQuantity());

        int status = productService.checkStorageProduct(storageId, storageName);
        // 验证仓库的商品是否有效
        if (status == 0) {
            int state = productService.checkAdditionProduct(productModel, storageId);
            // 验证提交的新增商品信息是否有效
            if (state == 2) return Result.error("商品名称不可为空");
            if (state == 3) return Result.error("商品价格不可小于0");
            if (state == 4) return Result.error("商品描述不可为空");
            if (state == 5) return Result.error("商品数量不可大于库存数量");
            if (state == 1) {
                productModel.setStatus(0);
                productModel.setStorage_id(storageId);
                productService.addProduct(productModel);
                return Result.success("添加成功");
            }
        }

        return Result.error("该库存商品不存在");
    }

    /**
     * 上架/下架商品
     * 上架前商品状态只能为未上架或已下架
     * 下架前商品状态只能为已上架或已售罄
     * */
    @GetMapping("api/modify-product-status")
    public Result putProduct (int id, int status) {
        String message = "请重新尝试";
        // 上架商品
        if (status == 1) {
            return productService.checkPutProduct(id, 1) == 1 ?
                    Result.success("上架成功") :
                    Result.error(message);
        }
        // 下架商品
        if (status == 2) {
            return productService.checkDeleteProduct(id, 3) == 1 ?
                    Result.success("下架成功") :
                    Result.error(message);
        }
        return Result.success(message);
    }

    // 获取所有商品
    @GetMapping("api/products")
    public Result getProducts () {
        return Result.success(
                productService.getAllProduct()
        );
    }

    // 获取所有已上架商品
    @GetMapping("api/putted-products")
    public Result puttedProducts () {
        return Result.success(
                productService.getAllPuttedProduct()
        );
    }

    // 删除商品
    @GetMapping("api/delete-product")
    public Result deleteProduct (int id) {
        productService.deleteProduct(id);
        return Result.success("删除成功");
    }

    // 返回指定条数的商品
    @GetMapping("api/limit-products")
    public Result limitProduct (int start, int num) {
        return Result.success(productService.limitProducts(start, num));
    }

    // 修改商品
    @PostMapping("api/modify-product")
    public Result modifyProduct (@RequestBody ProductModel productModel) {
        productService.updateProduct(productModel);
        return Result.success();
    }

    // 获取所有库存商品
    @GetMapping("api/get-all-storage")
    public Result getAllStorage () {
        return Result.success(productService.getAllStorage());
    }

    // 通过名称搜索商品（可以模糊搜索）
    @GetMapping("api/search-product")
    public Result searchProductByName (String name) {
        return Result.success(productService.searchProductByName(name));
    }

}
