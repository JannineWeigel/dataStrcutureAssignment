package com.yuanjidong.shop.controller;

import com.yuanjidong.shop.mapper.UserMapper;
import com.yuanjidong.shop.model.UserModel;
import com.yuanjidong.shop.result.Result;
import com.yuanjidong.shop.service.LoginService;
import com.yuanjidong.shop.utils.JWT;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;

/**
 * @author 袁吉栋
 * @date 2023/9/16
 * @description 类LoginController负责接收登录相关的接口功能
 * */

@CrossOrigin("*")
@RestController
public class LoginController {

    private final LoginService loginService;
    private final UserMapper userMapper;

    @Autowired
    public LoginController (LoginService loginService, UserMapper userMapper) {
        this.loginService = loginService;
        this.userMapper = userMapper;
    }

    /**
     * 1.判断：用户名和密码为6-8位的英文和数字的组合，第一位为英文
     *  -i 错误直接返回“用户名或密码格式不正确”
     * 2.根据提交的用户名和密码进行数据匹配
     *  -i 未匹配成功返回“用户名或密码错误”
     * 3.验证通过后，下发JWT登录标识token
     * */
    @PostMapping("/api/login")
    public Result login (@RequestBody UserModel userModel) {

        String username = userModel.getUsername();
        String password = userModel.getPassword();

        // 1.判断：用户名和密码为6-8位的英文和数字的组合，第一位为英文
        if (!loginService.verifyLogin(username, password))
            return Result.error("用户名或密码格式不正确!");

        // 2.根据提交的用户名和密码进行数据匹配
        UserModel model = userMapper.verifyUser(username, password);
        if (model == null)
            return Result.error("用户名或密码错误!");

        // 3.验证通过后，下发JWT登录标识token
        UserModel user = new UserModel();
        LinkedHashMap<String, Object> map = new LinkedHashMap<String, Object>();
        user.setId(model.getId());
        map.put("userId", user);

        return Result.success(JWT.generateJWT(map));
    }

}
