package com.yuanjidong.shop.mapper;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public class SellMapper {
}
