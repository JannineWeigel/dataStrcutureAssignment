package com.yuanjidong.shop.mapper;

import com.yuanjidong.shop.model.ProductModel;
import com.yuanjidong.shop.model.PurchaseModel;
import com.yuanjidong.shop.model.StorageModel;
import com.yuanjidong.shop.model.UserModel;
import org.apache.ibatis.annotations.*;
import org.springframework.web.bind.annotation.DeleteMapping;

import java.util.ArrayList;

/**
 * @author 袁吉栋
 * @date 2023/9/16
 * @description 接口ProductMapper声明接口并操作有关商品Product商品表
 * */

@Mapper
public interface ProductMapper {

    // 检查商品是否存在
    int checkExist (int id, String name);

    // 获取商品状态
    int getProductStatus (String name);

    // 获取库存数量
    int getStorageQuantity (int id);

    // 添加商品
    void addProduct (ProductModel productModel);

    // 检查上架/下架商品
    int checkPutProduct (int id);

    // 上架/下架
    void setProductStatus (int id, int status);

    // 获取所有商品
    ArrayList<ProductModel> getAllProduct ();

    // 获取所有已上架商品
    ArrayList<ProductModel> getAllPuttedProduct ();

    // 删除商品
    void deleteProduct (int id);

    // 获取指定条数商品
    ArrayList<ProductModel> limitProducts (int start, int num);

    // 修改商品
    void updateProduct (ProductModel productModel);

    // 查询商品数量
    int getStorageQuantityByProductId (int id);

    // 获取所有仓库商品
    ArrayList<StorageModel> getAllStorage ();

    // 搜索商品
    ArrayList<ProductModel> searchProductByName (String name);

}
