package com.yuanjidong.shop.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author 袁吉栋
 * @date 2023/9/28
 * @description 类PurchaseModel实体封装了进货商品的属性
 * */

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PurchaseModel {

    private int id;  // 订单id
    private String name;  // 购买商品名称
    private String date;  // 购买商品日期
    private Integer quantity;  // 购买商品数量
    private Double price;  // 购买商品价格
    private String description;  // 购买商品描述
    private Integer status;  // 购买商品状态 -> 0: 未发货, 1: 已发货, 2: 已入库

}
