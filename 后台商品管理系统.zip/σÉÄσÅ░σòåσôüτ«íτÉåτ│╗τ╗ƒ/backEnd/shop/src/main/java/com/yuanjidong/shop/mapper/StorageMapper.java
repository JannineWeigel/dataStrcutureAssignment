package com.yuanjidong.shop.mapper;

import com.yuanjidong.shop.model.PurchaseModel;
import com.yuanjidong.shop.model.StorageModel;
import org.apache.ibatis.annotations.Mapper;

import java.util.ArrayList;

@Mapper
public interface StorageMapper {

    // 获取所有库存商品
    ArrayList<StorageModel> allStorage ();

    // 入库新商品
    void enterStorage (PurchaseModel purchaseModel);

    // 入库已有商品
    void enterExistStorage (int id, String name, int newQuantity);

    // 检查重复的商品名
    int checkDuplicateName (String name);

    // 获取商品数量
    int getQuantity (String name);

}
