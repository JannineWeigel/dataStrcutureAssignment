package com.yuanjidong.shop.utils;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

import java.util.Date;
import java.util.LinkedHashMap;

/**
 * @author 袁吉栋
 * @date 2023/9/16
 * @description 类JWT负责生成和解析JavaWebToken令牌
 * */

public class JWT {

    // 令牌的编码标识
    private static final String key = "yuanjidong";

    // 令牌的过期时间（1天）
    private static final Long expire = 1000L * 60L * 60L * 24L;

    /**
     * 这里使用LinkedHashMap这种线性hash表的格式来存储令牌中用户的信息
     * 它保持了插入顺序，即元素的顺序与插入它们的顺序相同
     * */
        public static String generateJWT (LinkedHashMap<String, Object> map) {
            return Jwts.builder()
                    .signWith(SignatureAlgorithm.HS256, key)
                    .setClaims(map)
                    .setExpiration(new Date(System.currentTimeMillis() + expire))
                    .compact();
    }

    public static Claims parseJwt (String jwt) {
        return Jwts.parser()
                .setSigningKey(key)
                .parseClaimsJws(jwt)
                .getBody();
    }

}
