package com.yuanjidong.shop.service;

import org.springframework.stereotype.Service;

/**
 * @author 袁吉栋
 * @date 2023/9/16
 * @description 类LoginService抽离了一些关于登录的繁琐业务逻辑
 * */

@Service
public class LoginService {

    /**
     * 1.首先判断用户名是否为6-8位，不是就返回false
     * 2.然后判断用户名和密码的第一位是否为英文，不是就返回false
     * 3.接着验证用户名和密码是否为英文和数字组成，不是就返回false
     * */
    public boolean verifyLogin (String username, String password) {

        // 验证是否为6-8位
        if (username.length() < 6 || username.length() > 8 || password.length() < 6 || password.length() > 8) {
            return false;
        }

        // 判断用户名和密码的第一位是否为英文
        char firstChar = username.charAt(0);
        if (!Character.isLetter(firstChar)) {
            return false;
        }

        // 验证用户名和密码是否由英文字母和数字组成
        return isEngOrNum(username) && isEngOrNum(password);
    }

    // 判断是否全为英文或数字
    private boolean isEngOrNum(String input) {
        for (char c : input.toCharArray()) {
            if (!Character.isLetterOrDigit(c)) {
                return false;
            }
        }
        return true;
    }

}
