package com.yuanjidong.shop.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author 袁吉栋
 * @date 2023/9/16
 * @description 类UserModel实体封装了用户的属性
 * */

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserModel {

    private int id;
    private String username;
    private String password;

}
