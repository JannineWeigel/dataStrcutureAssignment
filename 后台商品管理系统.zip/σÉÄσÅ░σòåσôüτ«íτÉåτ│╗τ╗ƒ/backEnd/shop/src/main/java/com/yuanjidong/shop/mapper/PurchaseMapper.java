package com.yuanjidong.shop.mapper;

import com.yuanjidong.shop.model.PurchaseModel;
import com.yuanjidong.shop.model.StorageModel;
import org.apache.ibatis.annotations.Mapper;

import java.util.ArrayList;
import java.util.Date;

/**
 * @author 袁吉栋
 * @date 2023/9/16
 * @description 接口PurchaseMapper声明接口并操作有关商品Purchase商品表
 * */

@Mapper
public interface PurchaseMapper {

    // 获取所有订单
    ArrayList<PurchaseModel> allOrders();

    // 获取单个订单
    PurchaseModel unitOrder (int id);

    // 修改订单状态
    void modifyStatus(int id, int status);

    // 添加订单
    void addOrder (PurchaseModel purchaseModel);

    // 根据名字查找订单
    ArrayList<PurchaseModel> findPurchaseByName (String name, Date start, Date end);

    // 获取所有库存
    ArrayList<StorageModel> getAllStorage ();

}
