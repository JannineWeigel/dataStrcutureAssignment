package com.yuanjidong.shop.service;

import com.yuanjidong.shop.mapper.PurchaseMapper;
import com.yuanjidong.shop.mapper.StorageMapper;
import com.yuanjidong.shop.model.PurchaseModel;
import com.yuanjidong.shop.model.StorageModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Date;

/**
 * @author 袁吉栋
 * @date 2023/10/5
 * @description 类PurchaseService抽离了一些关于购买产品的繁琐业务逻辑
 * */

@Service
public class PurchaseService {

    private final PurchaseMapper purchaseMapper;
    private final StorageMapper storageMapper;

    // 依赖注入
    @Autowired
    public PurchaseService (PurchaseMapper purchaseMapper, StorageMapper storageMapper) {
        this.purchaseMapper = purchaseMapper;
        this.storageMapper = storageMapper;
    }

    // 获取所有订单
    public ArrayList<PurchaseModel> allOrders () {
        return purchaseMapper.allOrders();
    }

    /**
     * 修改订单状态
     * 如果入库，检查仓库是否有该品类的商品
     *  -有的话直接增加数量
     *  -没有的话仓库添加一条记录
     * */
    public void modifyStatus (int id, int status) {
        if (status == 2) {
            // 新入库的订单
            PurchaseModel purchaseModel = purchaseMapper.unitOrder(id);

            // 该订单已入库
            if (purchaseModel.getStatus() == 2) {
                return;
            }

            // 检查库里是否有该商品
            if (storageMapper.checkDuplicateName(purchaseModel.getName()) > 0) {
                int quantity = storageMapper.getQuantity(purchaseModel.getName());
                int newQuantity = purchaseModel.getQuantity() + quantity;
                storageMapper.enterExistStorage(purchaseModel.getId(), purchaseModel.getName(), newQuantity);
            }
            else {
                storageMapper.enterStorage(purchaseModel);
            }
        }
        purchaseMapper.modifyStatus(id, status);
    }

    /**
     * 1.商品名称长度在20个字符内
     * 2.日期不超过当前日期
     * 3.价格大于0
     * 4.状态未给的话默认为1
     * 5.产品介绍不可为空
     * */
    public String addOrder (PurchaseModel purchaseModel) {
        // 1. 商品名称长度在20个字符内
        if (purchaseModel.getName() != null && purchaseModel.getName().length() > 20) {
            return "商品名称长度不能超过20字符";
        }

        // 2. 验证正确格式，日期不超过当前日期
        if (purchaseModel.getDate() != null && purchaseModel.getDate().isEmpty()) {
            try {
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                LocalDate.parse(purchaseModel.getDate(), formatter);
            } catch (DateTimeParseException e) {
                return "订单日期格式不正确，应为yyyy-MM-dd";
            }
        }
        LocalDate currentDate = LocalDate.now();
        LocalDate purchaseDate = LocalDate.parse(purchaseModel.getDate());
        if (purchaseDate.isAfter(currentDate)) {
            return "日期不能超过当前日期";
        }

        // 3. 价格大于0
        if (purchaseModel.getPrice() == null) {
            return "价格不可为空";
        }
        if (purchaseModel.getPrice() <= 0) {
            return "价格必须大于0";
        }

        // 4. 状态默认为0
        if (purchaseModel.getStatus() == null) {
            purchaseModel.setStatus(0);
        }

        // 5. 产品介绍不可为空
        if (purchaseModel.getDescription() == null || purchaseModel.getDescription().isEmpty()) {
            return "产品描述不可为空";
        }

        System.out.println(purchaseModel);
        purchaseMapper.addOrder(purchaseModel);
        return "添加成功！";
    }

    // 根据名字查找订单
    public ArrayList<PurchaseModel> findPurchaseByName (String name, String start, String end) {
        // 验证日期格式
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date startDate = null;
        Date endDate = null;

        try {
            if (start != null && !start.isEmpty()) {
                startDate = dateFormat.parse(start);
            }
            if (end != null && !end.isEmpty()) {
                endDate = dateFormat.parse(end);
            }
        } catch (ParseException e) {
            throw new IllegalArgumentException("日期格式必须为yyyy-MM-dd");
        }

        if (startDate != null && endDate != null && startDate.after(endDate)) {
            throw new IllegalArgumentException("开始日期不能晚于结束日期");
        }

        // 处理日期范围
        if (start != null && !start.isEmpty() && (end == null || end.isEmpty())) {
            // 如果start有值而end没有值，将end设置为当前日期
            endDate = new Date();
        }
        if (end != null && !end.isEmpty() && (start == null || start.isEmpty())) {
            // 如果end有值而start没有值，将start设置为2000-01-01
            try {
                startDate = dateFormat.parse("2000-01-01");
            } catch (ParseException e) {
                // 处理解析异常
            }
        }
        return purchaseMapper.findPurchaseByName("%" + name + "%", startDate, endDate);
    }

    // 获取所有库存
    public ArrayList<StorageModel> getAllStorage () {
        return purchaseMapper.getAllStorage();
    }

}
