package com.yuanjidong.shop.controller;

import com.yuanjidong.shop.model.PurchaseModel;
import com.yuanjidong.shop.model.SearchModel;
import com.yuanjidong.shop.result.Result;
import com.yuanjidong.shop.service.PurchaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @author 袁吉栋
 * @date 2023/9/28
 * @description 类PurchaseController负责接收有关进货商品操作的接口功能
 * */

@RestController
public class PurchaseController {

    private final PurchaseService purchaseService;

    @Autowired
    public PurchaseController (PurchaseService purchaseService) {
        this.purchaseService = purchaseService;
    }

    // 获取所有订单信息
    @GetMapping("api/purchases")
    public Result allOrders () {
        return Result.success(purchaseService.allOrders());
    }

    // 修改订单状态
    @GetMapping("api/modify-purchase/{id}")
    public Result modifyStatus (@PathVariable int id, int status) {
        if (status > 2 || status < 0) return Result.error("请输入正确的物流信息！");
        purchaseService.modifyStatus(id, status);
        return Result.success();
    }

    // 新增订单信息
    @PostMapping("api/add-purchase")
    public Result addOrder (@RequestBody PurchaseModel purchaseModel) {
        if (purchaseService.addOrder(purchaseModel).equals("添加成功！"))
            return Result.success(purchaseService.addOrder(purchaseModel));
        return Result.error(purchaseService.addOrder(purchaseModel));
    }

    // 根据名字查询订单
    @PostMapping("api/search-purchase")
    public Result searchPurchase (@RequestBody SearchModel searchModel) {
        return Result.success(purchaseService.findPurchaseByName(searchModel.getName(), searchModel.getStart(), searchModel.getEnd()));
    }

}
