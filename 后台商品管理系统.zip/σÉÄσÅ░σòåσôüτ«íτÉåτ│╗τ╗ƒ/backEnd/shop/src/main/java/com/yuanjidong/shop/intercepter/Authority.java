package com.yuanjidong.shop.intercepter;

import com.alibaba.fastjson.JSONObject;
import com.yuanjidong.shop.result.Result;
import com.yuanjidong.shop.utils.JWT;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

/**
 * @author 袁吉栋
 * @date 2023/9/16
 * @description 类Authority实现HandlerInterceptor接口以重写拦截器的业务逻辑
 * */

@Slf4j
@Component
public class Authority implements HandlerInterceptor {

    // 主要的检查逻辑代码在这儿
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        // 打印日志
        log.info("---=====PRE_HANDLE METHOD=====---");
        String url = request.getRequestURL().toString();
        log.info("REQUEST URL: " + url);
        if (url.contains("/login")) return true;

        // 获取令牌信息进行验证
        String jwt = request.getHeader("token");
        // 如果没有登录
        if (!StringUtils.hasLength(jwt)) {
            String data = JSONObject.toJSONString(Result.error("NOT_LOGIN"));
            response.getWriter().write(data);
            log.error("NOT LOGIN");
            return false;
        }
        // 解析jwt令牌
        try {
            JWT.parseJwt(jwt);
            log.info("TOKEN HAS BEEN PARSED!");
        } catch (Exception e) {
            log.warn("TOKEN HASN'T BEEN PARSED!");
            String data = JSONObject.toJSONString(Result.error("UNAUTHORIZED"));
            response.getWriter().write(data);
            return false;
        }

        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        log.info("POST_HANDLE METHOD...");
//        HandlerInterceptor.super.postHandle(request, response, handler, modelAndView);
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        log.info("AFTER_HANDLE METHOD...");
//        HandlerInterceptor.super.afterCompletion(request, response, handler, ex);
    }
}
