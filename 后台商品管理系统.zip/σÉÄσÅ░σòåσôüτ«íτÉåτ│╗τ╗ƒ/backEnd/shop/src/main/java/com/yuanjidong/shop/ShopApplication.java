package com.yuanjidong.shop;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.IOException;
import java.io.InputStream;

@SpringBootApplication
public class ShopApplication {

    /**
     * @author 袁吉栋
     * @date 2023/9/16
     * @description 后台管理系统
     *
     * 班级：软件2341
     * 姓名：袁吉栋
     * 学号：2305224134
     * 完成作业所用时间（估计）：1周
     * */
    public static void main(String[] args) {
        SpringApplication.run(ShopApplication.class, args);
    }

}
